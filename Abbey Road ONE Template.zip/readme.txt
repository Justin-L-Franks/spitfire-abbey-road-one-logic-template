****************************************************************************************************
*  Logic Pro template for Spitfire Abbey Road One: Orchestral Foundations                          *
*  V1.0.0 (2021-01-23)                                                                             *
*                                                                                                  *
*  Copyright (c) 2021 by Justin L. Franks (justin.franks@gmail.com)                                *
*  Licensed under the GPL V3 license.                                                              *
*                                                                                                  *
*  https://github.com/Justin-L-Franks/spitfire-abbey-road-one-logic-template                       *
****************************************************************************************************

====================================================================================================
Overview
----------------------------------------------------------------------------------------------------

This is a Logic Pro template for Spitfire Audio's Abbey Road One: Orchestral Foundations sample library. It is similar to the template provided by Spitfire for their BBCSO libraries.

IMPORTANT: All of the instances of the AR1 plugin in this template are loading a user preset which only includes the specific articulations which are used. Each of these presets are included with the template. You just need to copy the 'user' folder into the 'Templates' folder of your copy of AR1. If you have created some of your own presets before, then the 'Template/user' folder already exists in your copy of AR1, so just copy the contents of the 'user' folder into the 'Templates/user' folder.

Each category of instruments (Full orchestra, Strings, Brass, Woodwinds, and Percussion) has its own track stack, with three busses for different types of articulation:

Full orchestra: Longs, shorts, swells 
Strings: Longs, shorts, pizzicato + tremolo
Brass: Longs, shorts, swells
Woods: Longs, shorts, swells
Percussion: Drums, metals, tuned

Each section available in the library (high strings, horns, low woods, etc.) has three tracks, corresponding to each of those busses. Percussion has individual tracks for each instrument (bass drum, suspended cymbals, glockenspiel, etc.).

Only the default Mix 1 mic is used for all instrument tracks.

There is also a reverb send for each track stack. I use R4 for reverb, but changed this to the Chroma reverb included with Logic for compatibility. All of the reverb sends are turned on, with just a touch of reverb added. Long articulations have the highest amount of reverb, followed by swells, with short articulations having the least reverb.

Each track also has a Gain plugin added for balancing. I only did a very quick and rough balancing, to the neighborhood of -12 dB (and peaking up to around -6 dB depending on the instrument) for three or four simultaneous notes played at maximum dynamics / velocity. This *will* need adjustment to your own preferences, but should give a decent starting point.

The routing is as follows:

Section articulation type(s) ==> Full section articulation type(s) ==> Full section ==> Full mix
                                       \ 
                                        ===> Effects send(s)

So, for the low string longs, it is Low strings longs ==> Strings longs ==> Strings ==> Full mix.    
                                              
====================================================================================================
Bussing
----------------------------------------------------------------------------------------------------                                              

Bus 10: Full orchestra
Bus 20: Strings
Bus 30: Brass
Bus 40: Woodwinds
Bus 50: Percussion
Bus 250: Full Mix

Busses X1-X4: Articulation type(s).
    Bus X1: Longs (for Percussion: Drums)
    Bus X2: Shorts (for Percussion: Metals)
    Bus X3: Swells (for Strings: Pizzicato & Tremolo, and for Percussion: Tuned)
    Bus X4: unused

(Bus 11 for Full Orchestra Longs, Bus 42 for Woods Shorts, Bus 53 for Tuned Percussion, etc.)

Busses X5-X9: Effects sends
    Bus X5: Reverb
    Busses X6-X9: unused

(Bus 25 for Strings Reverb, Bus 35 for Brass Reverb, and so forth. You can use the X6-X9 busses for any additional effects sends for each track stack.)







1	Tracks / Mixer / List
2	Tracks
3	Mixer
4	Tracks / Piano Roll
5	Piano Roll
6	Tracks / Score
7	Score
8	Tracks / Mixer / List / Prints
9	Tracks / Wave Editor
